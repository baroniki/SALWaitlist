

public class CP {
	public boolean isCP;
	public String classID;
	public String emailToRemove;
}
