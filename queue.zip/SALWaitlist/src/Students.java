import java.util.ArrayList;

public class Students {
	public String Email = null;
	public String Fname = null;
	public String Lname = null;
	public String Profile_Picture_URL = null;
	public String Phone_Number = null;
	public ArrayList<Integer> classes = null;
}
